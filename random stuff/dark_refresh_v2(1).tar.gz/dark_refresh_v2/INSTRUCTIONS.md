# Section files — TitleBlock removed (v2 fix)

Just six section files, with `<TitleBlock />` calls removed. The `SheetMeta` (top-left mono block) stays. The right side of every section is empty space, ready for the building animation.

## Install

```bash
tar -xzf ~/Downloads/dark_refresh_v2.tar.gz --strip-components=1
```

That overwrites the six section files inside `app/components/sections/`. No other file changes.

## Restart

```bash
rm -rf .next
npm run dev
```

## Verify

Visit `localhost:3000` — sections should render with:
- `▸ A-001 · Layer · 0-Base` etc. in the top-left of each section (SheetMeta — kept)
- Nothing in the top-right (was the title block, now removed)
- All other content unchanged from the dark refresh

Tell me ✅ when it's clean and we move on to the building animation.
