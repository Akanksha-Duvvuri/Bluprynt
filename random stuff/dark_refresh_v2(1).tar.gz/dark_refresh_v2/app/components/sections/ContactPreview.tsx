import Link from "next/link";
import Sheet from "../Sheet";
import { SheetMeta } from "../TitleBlock";
import ContactForm from "../ContactForm";
import styles from "./ContactPreview.module.css";

export default function ContactPreview() {
  return (
    <Sheet id="contact" tone="deep">
      <SheetMeta
        sheetCode="A-005"
        lines={["Layer · CONTACT", "Reply · < 1 business day"]}
      />

      <div className="sheet-body">
        <div className="section-head">
          <div className="section-head-left">
            <div className="label">▸ A-005 · Start a project</div>
            <h2 className="title">
              Tell us
              <br />
              what you&apos;re <span className="em">building.</span>
            </h2>
          </div>
          <div className="section-head-right">
            One reply within a business day. If your message mentions a service
            area, you&apos;ll get a tailored FAQ alongside our personal reply.
          </div>
        </div>

        <div className={styles.formWrap}>
          <ContactForm />
        </div>

        <div className="section-foot">
          <Link href="/contact" className="text-link">
            Or open the full contact page →
          </Link>
        </div>
      </div>
    </Sheet>
  );
}
