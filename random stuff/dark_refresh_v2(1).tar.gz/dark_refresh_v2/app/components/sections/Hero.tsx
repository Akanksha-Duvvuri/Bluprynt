import Sheet from "../Sheet";
import { SheetMeta } from "../TitleBlock";
import styles from "./Hero.module.css";

export default function Hero() {
  return (
    <Sheet id="hero" tone="deep">
      <SheetMeta
        sheetCode="A-001"
        lines={["Layer · 0-Base", "Drawn by · BCG"]}
      />

      <div className="sheet-body">
        <div className={styles.heroLabel}>▸ A-001 · Engineering accuracy</div>

        <h1 className={styles.heroTitle}>
          The firm
          <br />
          you call <span className={styles.em}>before</span>
          <br />
          you build.
        </h1>

        <p className={styles.heroSub}>
          Civil and infrastructure pre-consulting for owners, lenders, and
          developers. Independent technical opinions before commitments harden —
          on the record, in writing, defensible to a board.
        </p>

        <div className={styles.heroCtas}>
          <a href="/contact" className="btn-primary">
            Start a project →
          </a>
          <a href="/projects" className={styles.heroLink}>
            See our work →
          </a>
        </div>

        <div className={styles.cmd}>
          <span className={styles.prompt}>Command:</span> _SELECT — move cursor to
          inspect
          <span className={styles.cursor} />
        </div>
      </div>
    </Sheet>
  );
}
