# Services Step 1 — Database schema

Adds the `services` table to your database and seeds it with all 5 services from your current `lib/services.ts`. After this step, you'll have a populated `services` table ready for the admin CRUD in Step 2.

Estimated time: 5 minutes.

---

## Step 1.1 — Replace schema

Overwrite `db/schema.ts` with the version in this bundle.

**Diff from your current version:**
- Adds the `services` table (10 fields + 2 timestamps)
- Adds the `Service` / `NewService` TypeScript type exports

Existing tables (`projects`, `testimonials`, `users`, `form_submissions`, `email_log`) are unchanged.

## Step 1.2 — Add the new seed script

Place `scripts/seed-services.ts` from this bundle into your `scripts/` folder alongside `seed.ts` and `create-admin.ts`.

**Note:** All 5 services from your `lib/services.ts` are already pre-filled. You don't need to edit anything.

## Step 1.3 — Add an npm script

In `package.json`, find the `"scripts"` block. Add ONE new line:

```json
{
  "scripts": {
    ...
    "db:seed:services": "tsx --env-file=.env.local scripts/seed-services.ts"
  }
}
```

## Step 1.4 — Generate + apply the migration

```bash
npm run db:generate
```

Output should show:

```
[✓] Your SQL migration file ➜ drizzle/0002_xxxxx.sql 🚀
```

(Number depends on how many migrations you've already run.)

Open the generated SQL file in `/drizzle/`. You should see:

```sql
CREATE TABLE IF NOT EXISTS "services" (...)
```

Then apply:

```bash
npm run db:migrate
```

## Step 1.5 — Seed the data

```bash
npm run db:seed:services
```

Output:

```
Seeding 5 service(s)...

  ✓ preconstruction-feasibility — Pre-construction Feasibility
  ✓ cost-estimation-tendering — Cost Estimation & Tendering
  ✓ constructability-review — Constructability Review
  ✓ project-controls — Project Controls
  ✓ advisory-owners-rep — Advisory & Owner's Representative

✓ All services seeded.
```

## Step 1.6 — Verify in Drizzle Studio

```bash
npm run db:studio
```

In the sidebar you should now see a `services` table with 5 rows.

Check:
- `deliverables` and `when_to_engage` show as JSON strings like `["item 1", "item 2"]` — that's correct
- `featured` is `true` for the first 3, `false` for the last 2
- `sort_order` is 10, 20, 30, 40, 50

## Step 1.7 — TypeScript still compiles

```bash
npx tsc --noEmit
```

No errors expected.

---

## When you're done

Tell me one of:

- ✅ Migration applied, 5 services in the database, ready for Step 2
- ⚠ Failed at step X — paste the error

Step 2 is the bulk of the work: admin pages, forms, API routes, and the rewrite of `lib/services.ts` to read from the database. About 11 files. After Step 2, the admin panel has Services in the sidebar and the founders can edit them through forms.

**Don't run Step 2's bundle until Step 1 is verified green.** Step 2 assumes the table is populated.
