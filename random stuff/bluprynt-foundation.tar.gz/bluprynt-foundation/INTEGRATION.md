# Bluprynt foundation — integration notes

This pack drops the design tokens, providers, hooks, and global CAD chrome into your existing project. Direction-independent: works regardless of which animation we wire up for the hero.

## What's in here

```
app/
  globals.css                 ← replaces or merges with your existing globals.css
  layout.tsx                  ← root layout: html, body, fonts, SheetProvider
  (public)/layout.tsx         ← NEW route group — wraps public pages with CAD chrome

components/cad/
  CADNavbar.tsx + .module.css
  CADStatusBar.tsx + .module.css
  CADCrosshair.tsx + .module.css
  SectionDivider.tsx + .module.css
  SheetTag.tsx + .module.css

lib/cad/
  SheetProvider.tsx           ← context for the current sheet code
  useSheetObserver.ts         ← attach to a section, updates sheet on scroll-in
  useReducedMotion.ts         ← reactive prefers-reduced-motion hook
```

## Path alias

The imports use `@/lib/...` and `@/components/...`. If your `tsconfig.json` doesn't have the `@/*` path alias yet, add:

```jsonc
{
  "compilerOptions": {
    "paths": { "@/*": ["./*"] }
  }
}
```

## Route groups: (public) vs (authed)

Move your existing public pages into `app/(public)/`:

```
app/
  layout.tsx                ← root (this pack — fonts + SheetProvider)
  (public)/
    layout.tsx              ← this pack — mounts navbar/statusbar/crosshair
    page.tsx                ← homepage (next turn)
    work/page.tsx
    services/page.tsx
    about/page.tsx
    contact/page.tsx
  (authed)/
    layout.tsx              ← your existing admin layout, untouched
    admin/...
```

Route groups don't affect URLs — `/admin/login` stays `/admin/login`. They just let you give different layouts to different parts of the app. The CAD chrome only renders for `(public)`, so admin keeps its own chrome and the crosshair never shows up over the admin panel.

If you'd rather not move pages, the alternative is to read `x-pathname` (you already have this pattern in middleware) inside the root layout and conditionally render chrome. The route group is cleaner long-term.

## globals.css merge

Your existing `globals.css` has admin styles. You have two choices:

1. **Merge** — paste the `:root { ... }` block at the top of your existing globals, then the reset section, removing duplicates.
2. **Replace** — admin currently uses brand-styled login. If admin styles only depend on the same tokens (likely), full replace works.

If unsure, paste the new file in alongside as `globals.cad.css` and import it from the root layout below `./globals.css` — tokens win on cascade order.

## Verifying it works

After dropping files in:

1. `pnpm dev` (or your script). Tokens loaded → page background should be `#0D0C08` (deep charcoal), text cream.
2. Move one public page into `(public)/` — e.g. `app/page.tsx` → `app/(public)/page.tsx`. Navbar and status bar should appear.
3. Move your cursor on desktop — gold crosshair tracks with mechanical lag, X/Y/SHEET label trails bottom-right.
4. Scroll down 80+ pixels — navbar gets a backdrop blur and the bottom border darkens.
5. Resize to mobile width — hamburger appears, crosshair disappears (touch device check).
6. Status bar at bottom shows: `Layer: 0-Base · Snap: NN · Grid: ON · Sheet: A-001 · ● Status: Live · Rev: 01`. Snap counter ticks as you move; the green dot pulses.

## Caveats and notes

- **Cursor accessibility.** `cursor: none` is mandatory for the crosshair effect but it's an accessibility cost. The component already gates on `(pointer: fine)` so touch users get native cursors. If you want to give desktop users an opt-out later, the toggle goes in the status bar — flip `body[data-crosshair]` between `"active"` and unset.

- **Sheet codes.** Default initial is `A-001`. Sections drive the global sheet via `useSheetObserver(code)`. The hero section will use `A-001`; subsequent sections `A-002` through `A-006` per the index we drafted.

- **No framer-motion yet.** The sliding navbar underline uses refs + CSS transforms, no library needed. We can add framer-motion later for richer scroll orchestration on the hero — but it's not a blocker.

- **next/font.** Three families load via `next/font/google` in the root layout (Inter Tight, Nunito, Space Mono). The CSS variables (`--font-inter-tight` etc.) are already wired through to globals.

## What's next

Foundation is in. Next turn:

1. The hero with the drawing-assembly building animation (the centerpiece).
2. The remaining five sections (`A-002` through `A-006`) per the sheet index.
3. The spotlight/grid-glow effect that follows the cursor inside each section.
4. The typing CAD command line at the bottom of the hero.

Want me to start with the hero + building drawing immediately, or hold for you to drop these in and confirm the chrome renders cleanly first?
