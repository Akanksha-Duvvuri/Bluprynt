# All-Dark Refresh — Install Instructions

End state: cream sections gone. Three ink tones cycling through six homepage sections. Mint promoted as a real second accent. Section dividers between every section. Pull-quotes giving cream a typographic moment.

Files in this bundle: 11

- 1 file modified: `app/globals.css` (full replacement)
- 1 file modified: `app/components/Sheet.tsx` (new tone API, replaces old variant API)
- 1 file new: `app/components/SectionDivider.tsx`
- 1 file modified: `app/page.tsx` (new structure with dividers)
- 5 section files modified: Hero, WorkPreview, ServicesPreview, Testimonials, AboutPreview, ContactPreview
- 1 file modified: `app/components/sections/Testimonials.module.css` (mint open-quote)
- 1 patches file: `PATCHES.css` — manual additions to two existing CSS files

Estimated install: 15 minutes.

---

## Step 1 — Replace files

Drop these into your project, overwriting existing:

```
app/globals.css                                  ← replaces existing
app/page.tsx                                     ← replaces existing
app/components/Sheet.tsx                         ← replaces existing
app/components/SectionDivider.tsx                ← NEW file
app/components/sections/Hero.tsx                 ← replaces existing
app/components/sections/WorkPreview.tsx          ← replaces existing
app/components/sections/ServicesPreview.tsx     ← replaces existing
app/components/sections/Testimonials.tsx         ← replaces existing
app/components/sections/Testimonials.module.css  ← replaces existing
app/components/sections/AboutPreview.tsx         ← replaces existing
app/components/sections/ContactPreview.tsx       ← replaces existing
```

The simplest way: extract the tarball at your project root with `--strip-components=1`.

## Step 2 — Apply the two PATCHES

`PATCHES.css` is NOT a file to drop in directly. It contains two small CSS rules that need to be added to existing files. Open `PATCHES.css` and follow its instructions:

- **Patch 1**: Add ~10 lines to `app/projects/[slug]/page.module.css` (mint outcome border)
- **Patch 2**: Add ~3 lines to `app/admin/(authed)/page.module.css` (mint stat numbers)

These are 2-minute manual edits. Don't skip them — they're part of the refresh.

## Step 3 — Restart

```bash
rm -rf .next
npm run dev
```

## Step 4 — Walk the homepage and verify

Open `localhost:3000` and **scroll slowly from top to bottom**. Verify each:

### Visual rhythm

- [ ] Hero background is the deepest ink (`#0D0C08`)
- [ ] Work background is one step lighter (`#15130D`)
- [ ] Services background is one step warmer/softer than Work (`#1C1A14`)
- [ ] Testimonials returns to base ink
- [ ] About is soft again
- [ ] Contact is deepest again

Side-by-side on a wide monitor, the difference is subtle. On a phone, even more subtle. That's correct — the rhythm is there to be felt, not noticed.

### Section dividers

- [ ] Between every section, a horizontal gold dashed line appears
- [ ] On the left, the line is labeled `▸ TRANSITION · A-001 → A-002` (etc)
- [ ] On the right, a small dimension callout appears (`+1280`, etc)
- [ ] As you scroll past, the line ANIMATES drawing from left to right (one-shot)
- [ ] On mobile (≤1100px wide), the divider collapses to a thin gap with no labels or animation

### Mint accents

- [ ] On the Testimonials section, the open-quote `"` glyph at the top of each card is mint, NOT gold
- [ ] On the Testimonials section, the headline `"on the record"` em-portion is mint, not gold
- [ ] On a project case study (e.g. `/projects/eastwood-viaduct`), the "Outcome" section has a thin mint left-border on the body paragraph
- [ ] On `/admin` dashboard, the project count and testimonial count numbers render in mint

### Pull-quotes

- [ ] WorkPreview has a large thin cream phrase below the project grid: "Selected for what they taught us, not just what they paid us."
- [ ] ServicesPreview has one: "We answer the questions your design team won't ask."
- [ ] AboutPreview has one: "Independent on principle. Useful on purpose."

### Existing things still work

- [ ] Crosshair cursor follows on desktop, hidden on `/admin/*` and on touch
- [ ] Spotlight reveals the brighter drafting grid where the cursor hovers
- [ ] All inner pages (`/about`, `/services`, `/projects`, `/contact`) still render
- [ ] Admin login and admin pages still work
- [ ] Per-page case studies still load

---

## Common issues

### Sections look identical / no tone difference

Most likely: the new `Sheet.tsx` was overwritten but the section files still pass `variant="dark"` instead of `tone="base"`. Check by searching:

```bash
grep -rn 'variant=' app/components/
```

Should return zero results. If any remain, those section files weren't overwritten.

### Section dividers don't animate

`SectionDivider.tsx` is a client component. If the `"use client"` directive at the top got dropped (rare), the IntersectionObserver doesn't attach. Confirm:

```bash
head -2 app/components/SectionDivider.tsx
# expected: "use client";
```

### Pull-quotes don't render

The `.pull-quote` class is defined in `globals.css`. If the file wasn't fully overwritten, the class might be missing.

```bash
grep "pull-quote" app/globals.css | head -3
```

Should match. If not, re-extract `globals.css`.

### Mint stat numbers not appearing on /admin

You skipped Patch 2. Reopen `PATCHES.css`, copy the second snippet, paste into `app/admin/(authed)/page.module.css`. Restart.

### "Cannot read property 'tone' of undefined"

A custom Sheet usage in your code (e.g. on inner pages) is still passing `variant`. Update those calls too — the API changed across the board.

```bash
grep -rn 'Sheet' app/ | grep variant
```

Anything that comes up needs `variant="dark"` swapped to `tone="base"` (or `tone="deep"` / `tone="soft"`, your call).

---

## When you're done

Tell me one of:
- ✅ — looks great, build the building animation next
- ⚠ — something is off, here's a screenshot or description

The building animation comes next as a separate phase. With cream gone and the title block also gone, the right side of the page is now wide open for it.
