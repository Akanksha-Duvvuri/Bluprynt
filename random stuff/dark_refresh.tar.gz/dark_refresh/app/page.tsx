import Hero from "./components/sections/Hero";
import WorkPreview from "./components/sections/WorkPreview";
import ServicesPreview from "./components/sections/ServicesPreview";
import Testimonials from "./components/sections/Testimonials";
import AboutPreview from "./components/sections/AboutPreview";
import ContactPreview from "./components/sections/ContactPreview";
import SectionDivider from "./components/SectionDivider";

/**
 * Homepage — six sections cycling through the three ink tones.
 *
 *   Hero          → tone="deep"  (formal entry)
 *   Work          → tone="base"  (standard)
 *   Services      → tone="soft"  (warmer, humanized)
 *   Testimonials  → tone="base"  (settled in)
 *   About         → tone="soft"  (warmer, humanized)
 *   Contact       → tone="deep"  (formal close)
 *
 * Section dividers between each one — drafting lines that draw on
 * as you scroll past them.
 */
export default function HomePage() {
  return (
    <>
      <Hero />
      <SectionDivider from="A-001" to="A-002" dim="+1280" />
      <WorkPreview />
      <SectionDivider from="A-002" to="A-003" dim="+2560" />
      <ServicesPreview />
      <SectionDivider from="A-003" to="A-006" dim="+3840" />
      <Testimonials />
      <SectionDivider from="A-006" to="A-004" dim="+5120" />
      <AboutPreview />
      <SectionDivider from="A-004" to="A-005" dim="+6400" />
      <ContactPreview />
    </>
  );
}
