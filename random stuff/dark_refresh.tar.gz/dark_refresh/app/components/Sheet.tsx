import type { ReactNode } from "react";

interface SheetProps {
  /** Section ID — must match an entry in Crosshair's SHEET_MAP */
  id: string;
  /**
   * Tone — picks one of the three ink shades.
   *   "deep"  →  --ink-deep   (formal, anchor sections — Hero, Contact)
   *   "base"  →  --ink        (standard sections — Work, Testimonials)
   *   "soft"  →  --ink-soft   (warmer sections — Services, About)
   *
   * Cycling these gives the all-dark page subtle visual rhythm
   * without losing the unified feel.
   */
  tone: "deep" | "base" | "soft";
  /** Optional extra class on the section element */
  className?: string;
  /** Section content */
  children: ReactNode;
}

/**
 * Sheet — base wrapper for every section on the site.
 * Renders the faint default grid, the bright spotlight grid, the wash,
 * and corner ticks. Children render on top via z-index in their own styles.
 *
 * After the all-dark refresh: cream variant is gone. Sections cycle
 * through three ink tones to keep the dark page from feeling monolithic.
 */
export default function Sheet({
  id,
  tone,
  className = "",
  children,
}: SheetProps) {
  return (
    <section
      id={id}
      className={`sheet sheet-tone-${tone} ${className}`.trim()}
    >
      <div className="drawing-base" />
      <div className="drawing-bright">
        <div className="grid-fine" />
        <div className="grid-coarse" />
      </div>
      <div className="spot-wash" />
      <div className="corner-tick tl" />
      <div className="corner-tick tr" />
      <div className="corner-tick bl" />
      <div className="corner-tick br" />
      {children}
    </section>
  );
}
