import Link from "next/link";
import Sheet from "../Sheet";
import { TitleBlock, SheetMeta } from "../TitleBlock";
import { FOUNDERS } from "@/lib/founders";
import styles from "./AboutPreview.module.css";

export default function AboutPreview() {
  return (
    <Sheet id="about" tone="soft">
      <SheetMeta
        sheetCode="A-004"
        lines={["Layer · ABOUT", `Founders · ${FOUNDERS.length}`]}
      />
      <TitleBlock
        title="Bluprynt / About"
        rows={[
          { k: "Drwg No.", v: "BCG-004" },
          { k: "Sheet", v: "05 / 06" },
          { k: "Team", v: `${FOUNDERS.length} PRINCIPAL` },
        ]}
      />

      <div className="sheet-body">
        <div className="section-head">
          <div className="section-head-left">
            <div className="label">▸ A-004 · Who we are</div>
            <h2 className="title">
              Two engineers,
              <br />
              one <span className="em">premise.</span>
            </h2>
          </div>
          <div className="section-head-right">
            That the most expensive engineering decision is the one you
            didn&apos;t think hard enough about.
          </div>
        </div>

        <div className={styles.foundersGrid}>
          {FOUNDERS.map((f) => (
            <article key={f.name} className={styles.card}>
              <div className={styles.photo}>{f.initials}</div>
              <div className={styles.cardBody}>
                <div className={styles.role}>{f.role}</div>
                <div className={styles.name}>{f.name}</div>
                <p className={styles.bio}>{f.bio}</p>
                <div className={styles.credentials}>
                  {f.credentials.map((c) => (
                    <div key={c.k} className={styles.credRow}>
                      <span className={styles.credK}>{c.k}</span>
                      <span className={styles.credV}>{c.v}</span>
                    </div>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>

        <p className="pull-quote">
          Independent on principle. <span className="em">Useful</span> on
          purpose.
        </p>

        <div className="section-foot">
          <Link href="/about" className="text-link">
            More about the firm →
          </Link>
        </div>
      </div>
    </Sheet>
  );
}
