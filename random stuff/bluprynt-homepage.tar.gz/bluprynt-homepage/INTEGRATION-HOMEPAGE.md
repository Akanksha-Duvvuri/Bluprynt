# Bluprynt — Homepage Pack · Integration

This pack assumes the **foundation pack** is already integrated (globals.css
tokens, fonts wired in `app/layout.tsx`, `CADCrosshair`/`CADNavbar`/
`CADStatusBar` mounted, `lib/cad/useSheetObserver` and `useReducedMotion`
present, `components/cad/SectionDivider` present, `@/*` path alias set in
`tsconfig.json`).

If the foundation pack is **not** in yet, do that first — the homepage
references its tokens and hooks throughout.

---

## 1 · File placement

Drop these in at the matching paths:

```
your-repo/
├── app/
│   ├── page.tsx                                  ← REPLACES your current homepage
│   └── components/
│       └── sections/                             ← REPLACES your existing 6 stubs
│           ├── Hero.tsx              + .module.css
│           ├── WorkPreview.tsx       + .module.css
│           ├── ServicesPreview.tsx   + .module.css
│           ├── Testimonials.tsx      + .module.css
│           ├── AboutPreview.tsx      + .module.css
│           └── ContactPreview.tsx    + .module.css
│
├── components/cad/                               ← NEW additions
│   ├── BuildingDraft.tsx             + .module.css
│   └── SectionShell.tsx              + .module.css
│
└── lib/cad/                                      ← NEW additions
    ├── useScrollProgress.ts
    └── useTypewriter.ts
```

Quick way (zsh — quote brackets if you ever script around route groups):

```sh
cp -r bluprynt-homepage/app/components/sections/* path/to/repo/app/components/sections/
cp -r bluprynt-homepage/components/cad/*          path/to/repo/components/cad/
cp -r bluprynt-homepage/lib/cad/*                 path/to/repo/lib/cad/
cp    bluprynt-homepage/app/page.tsx              path/to/repo/app/page.tsx
```

---

## 2 · One layout decision

`<BuildingDraft />` is mounted directly in `app/page.tsx` (not in
`app/layout.tsx`), so it appears on `/` only. That's intentional — the
draft-the-building metaphor reads as a homepage device, and you probably
don't want a fixed building panel hovering over the work index or admin
routes.

If you change your mind, lift the import + `<BuildingDraft />` out of
`page.tsx` into a route-group layout (e.g. `app/(public)/layout.tsx`
once you create that group).

---

## 3 · Wiring the DB

Both `WorkPreview` and `Testimonials` accept typed props and fall back to
realistic placeholders when nothing is passed. The placeholders let you
preview the layout immediately; switch to real data when you're ready.

In `app/page.tsx`, convert to an async server component:

```tsx
import { getFeaturedProjects } from "@/lib/projects";
import { getFeaturedTestimonials } from "@/lib/testimonials";

export default async function HomePage() {
  const [projects, testimonials] = await Promise.all([
    getFeaturedProjects(3),
    getFeaturedTestimonials(3),
  ]);

  return (
    <>
      <BuildingDraft />
      <Hero />
      <SectionDivider fromCode="A-001" toCode="A-002" />
      <WorkPreview projects={projects} />
      …
      <Testimonials testimonials={testimonials} />
      …
    </>
  );
}
```

Type contracts the components expect (adapt your DB row shape to these,
or extend the types):

```ts
// WorkPreview
type Project = {
  id: string | number;
  slug: string;
  title: string;
  client?: string | null;
  location?: string | null;
  scope?: string | null;
  status: "active" | "review" | "pending" | string;
  category?: string | null;
};

// Testimonials
type Testimonial = {
  id: string | number;
  quote: string;
  author: string;
  role?: string | null;
  org?: string | null;
  project?: string | null;
};
```

A quick reminder from your earlier learnings: making the page async
**is** the async-migration trap. Every consumer up the tree (none here,
since `page.tsx` is a leaf) needs to handle the Promise. You're fine
because nothing wraps `HomePage`.

---

## 4 · Wiring the contact form

`ContactPreview.tsx` ships with a visual-only handler. Look for the
`TODO` comment in `handleSubmit` — that's where to swap in your real
action. You already have a `form_submissions` table in the schema, so
the natural shape is:

```tsx
"use server";
// app/actions/contact.ts
import { z } from "zod";
import { db } from "@/db";
import { formSubmissions } from "@/db/schema";

const ContactSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  company: z.string().optional(),
  type: z.string().min(1),
  location: z.string().optional(),
  message: z.string().min(1),
});

export async function submitContact(formData: FormData) {
  const parsed = ContactSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { ok: false, errors: parsed.error.flatten() };

  await db.insert(formSubmissions).values({
    ...parsed.data,
    createdAt: new Date(),
  });
  // TODO: trigger Resend email + log to email_log
  return { ok: true };
}
```

Then in `ContactPreview.tsx`:

```tsx
import { submitContact } from "@/app/actions/contact";

async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
  e.preventDefault();
  setSubmitting(true);
  try {
    const res = await submitContact(new FormData(e.currentTarget));
    if (res.ok) setSubmitted(true);
    // TODO: surface res.errors in the form if !res.ok
  } finally {
    setSubmitting(false);
  }
}
```

Reminder on Zod v4: it's `error: "..."` now, not `invalid_type_error`.

---

## 5 · How the building-draft animation works

`useScrollProgress` is a tiny RAF-throttled hook returning `0..1` for
page scroll. `BuildingDraft` writes that value to a CSS custom property
`--p` on its root element. Each SVG layer's opacity is computed as
`clamp(0, (var(--p) - start) * speed, 1)` — six layers, six thresholds.
The layer-1 outline also uses `stroke-dashoffset` for a draw-in effect.

This means **no JS animation loop, no framer-motion** — just one scroll
listener and the GPU.

Layer thresholds in `BuildingDraft.module.css`:

| Layer | Stage         | Reveals between |
| ----- | ------------- | --------------- |
| L1    | Outline       | 0.00 → 0.15     |
| L2    | Foundation    | 0.15 → 0.30     |
| L3    | Structure     | 0.30 → 0.50     |
| L4    | Envelope      | 0.50 → 0.70     |
| L5    | Annotations   | 0.70 → 0.85     |
| L6    | Title block   | 0.85 → 1.00     |

If you want the building to peak earlier (page is short and people
don't scroll all the way), tighten those ranges. The stage labels in
the bottom progress readout are mirrored from `stageFor()` — keep them
in sync if you change the splits.

`prefers-reduced-motion: reduce` reveals all six layers at full opacity
immediately and skips the draw-in. Tested in the CSS at the bottom of
the module file.

---

## 6 · Known things to double-check

A couple of items inherited from your stack quirks:

- **Markdown link corruption** — when you copy from chat, anything that
  reads like `process.env.X` can land as a hyperlink. None of these
  files contain that pattern, so you should be fine, but worth a glance
  at `BuildingDraft.tsx` (it's the longest file).
- **Partial paste check** — if you paste from chat instead of from the
  tarball, watch for the closing tags on the SVG in `BuildingDraft.tsx`
  and `AboutPreview.tsx`. Both have multi-hundred-line SVGs.
- **`.js` suffix on Vercel Linux** — only an issue with eslint configs;
  nothing in this pack adds eslint rules.

---

## 7 · Things deliberately not done

- **Form validation surface.** Errors aren't rendered yet. Wire your
  Zod schema's `.flatten()` output into per-field error states once you
  have the action working.
- **Full-bleed mobile building.** On `<= 960px` the building fades to
  `opacity: 0.35` and becomes a static backdrop behind the hero only.
  If you want it to follow scroll on mobile, change the
  `position: absolute` on `.wrap` back to `position: fixed` in
  `BuildingDraft.module.css` and tune the opacity.
- **Section dividers between A-005 and A-006** use the same dashed-line
  draw-in as every other pair. If the contact section feels too
  ceremonious to lead into with a divider, drop the last
  `<SectionDivider />` in `page.tsx`.
- **Testimonials count.** Currently caps at 3. Bump the
  `.slice(0, 3)` in `Testimonials.tsx` if your DB returns more and you
  want them all shown.

---

## 8 · Verification checklist

Run these after dropping the files in. None of them require the DB.

```sh
pnpm dev   # or your equivalent
```

1. `/` renders without errors.
2. Hero corner ticks draw in on mount; the gold "before" word arrives a
   beat after the rest of the headline; the command line types
   character by character with a blinking caret at the end.
3. As you scroll: the building on the right progressively gains
   foundation, structure, envelope hatching, dimensions, and a title
   block that fills in toward the end. The progress readout at
   bottom-right of the panel ticks `001%` → `100%` and the stage label
   advances through L1 → L6.
4. Spotlight follows your cursor in each section (faint cream halo).
5. Status bar at the bottom updates the SHEET field (A-001 → A-006) as
   you scroll into each section. (This relies on the foundation pack's
   `useSheetObserver` + `SheetProvider`.)
6. Form submits visually (sets the success state). `network` tab will
   be empty until you wire the action.
7. Reduced-motion check: `System Settings → Reduce Motion → on` — every
   animation should resolve to its end state immediately, with no
   typewriters, no scroll-driven reveals, no card lifts.

---

## 9 · If you want to deviate

Two natural directions you mentioned earlier:

- **All-dark + gradient instead of alternating cream/dark.** The
  `tone` prop on `<SectionShell>` accepts `"deep" | "base" | "soft"`,
  all three of which are charcoals. The pack already runs all-dark.
  For a gradient, replace the `background` style on `.section` with
  a vertical or radial linear-gradient between two of those tokens.
- **Replace the building with a scroll-driven construction
  animation.** That's literally what `BuildingDraft` is — scroll-driven
  assembly. The drawing-assembly metaphor was the chosen direction,
  but if you ever want a more literal "building rising out of the
  ground" reading, the scaffolding is here: `useScrollProgress` +
  `--p` custom property. Swap the SVG; keep the threshold logic.
